# Li Zhuwei

## Links

### Store Landing page
- http://janelleweiwei.org/aau/wnm608/li.zhuwei/store/index.php

### Store Admin page
- http://janelleweiwei.org/aau/wnm608/li.zhuwei/store/admin/index.php
- http://janelleweiwei.org/aau/wnm608/li.zhuwei/store/admin/users.php

## Docs
- https://docs.google.com/presentation/d/146QNNZY2OGPuxNailLB0Bh72Mnoq0e5FarIOffECvI8/edit?usp=sharing
