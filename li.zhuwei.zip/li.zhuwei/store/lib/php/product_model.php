<?php

class ProductModel {

  public $id, $date_create, $date_modified, $name, $price;
  public $description, $thumbnail, $images, $url, $category;

  public function __construct () {}

}

?>