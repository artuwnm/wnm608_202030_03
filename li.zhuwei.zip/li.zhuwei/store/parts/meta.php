<meta charset="UTF-8">
<meta name="viewport" content="width=device-width">
<script type="text/javascript" src="https://kit.fontawesome.com/041ded284b.js" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="lib/js/functions.js"></script>
<script type="text/javascript" src="js/templates.js"></script>
<script type="text/javascript" src="js/list.js"></script>
<script type="text/javascript" src="js/products.js"></script>
<script type="text/javascript" src="lib/js/index.js"></script>
<link rel="stylesheet" href="lib/css/gridsystem.css">
<link rel="stylesheet" href="lib/css/styleguide.css">
<link rel="stylesheet" href="css/storetheme.css">

