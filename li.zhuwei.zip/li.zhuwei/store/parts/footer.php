<footer>
  <div id="footer" style="width: 100%;">
    <p>© Zhuwei Li</p>
    <p>Terms & Conditions</p>
    <p>Privacy Policy</p>
    <p>Accessibility</p>
  </div>
</footer>